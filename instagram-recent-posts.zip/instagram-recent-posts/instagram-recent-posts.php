<?php
/*
Plugin Name: Instagram Recent Posts
Description: Fetches recent Instagram posts from a public account and stores them locally.
Version: 1.0
Author: Shaun Ong
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Debug file
function debug_file() {
    return plugin_dir_path(__FILE__) . 'debug.txt';
}



// Hook for adding admin menus
add_action('admin_menu', 'instagram_recent_posts_menu');

// Action function for the admin menu
function instagram_recent_posts_menu() {
    add_menu_page(
        'Instagram Recent Posts',
        'Instagram Recent Posts',
        'manage_options',
        'instagram-recent-posts',
        'instagram_recent_posts_settings_page'
    );
}

// Function to display the plugin settings page
function instagram_recent_posts_settings_page() {
    ?>
    <div class="wrap">
        <h1>Instagram Recent Posts Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('instagram_recent_posts_options_group');
            do_settings_sections('instagram-recent-posts');
            submit_button();
            ?>
        </form>
        
        <h2>Retrieved Instagram Posts:</h2>
        <p>
            Use the shortcode: <code>[instagram_recent_posts]</code> on your pages.
        </p>
        <p>
            The posts are locally stored in a file: <strong><a href="/wp-content/plugins/instagram-recent-posts/instagram_recent_posts_cache.json" target="_blank">instagram_recent_posts_cache.json</a></strong><br/>
            Debug file: <strong><a href="/wp-content/plugins/instagram-recent-posts/debug.txt" target="_blank">debug.txt</a></strong>
        </p>
        <fieldset class="notice">
            <p>
                <b>NOTE: Some instagram username accounts don't allow image thumbnails sharing from different domainname origins.</b>
            </p>
            <p>
                If you see missing image thumbnails below, you need to configure your instagram, to allow access to photos/videos here: 
                <a href="https://www.youtube.com/watch?v=G9dnUlwoq_8" target="_blank">https://www.youtube.com/watch?v=G9dnUlwoq_8</a>
            </p>
            <p>
                e.g. username: <strong>okanaskincare</strong> (only allows images, but not videos)
            </p>
        </fieldset>
        <div class="instagram-recent-posts-preview">
            <?php echo do_shortcode('[instagram_recent_posts]'); ?>
        </div>
    </div>
    <?php
}

// Hook for initializing settings
add_action('admin_init', 'instagram_recent_posts_settings_init');

// Function to initialize settings
function instagram_recent_posts_settings_init() {
    register_setting('instagram_recent_posts_options_group', 'instagram_recent_posts_username');
    register_setting('instagram_recent_posts_options_group', 'instagram_recent_posts_frequency');

    add_settings_section(
        'instagram_recent_posts_settings_section',
        'Plugin Settings:',
        null,
        'instagram-recent-posts'
    );

    add_settings_field(
        'instagram_recent_posts_username',
        'Instagram Username',
        'instagram_recent_posts_username_field_render',
        'instagram-recent-posts',
        'instagram_recent_posts_settings_section'
    );

    add_settings_field(
        'instagram_recent_posts_frequency',
        'Update Frequency (in minutes) minimum is 15 minutes',
        'instagram_recent_posts_frequency_field_render',
        'instagram-recent-posts',
        'instagram_recent_posts_settings_section'
    );

}

function instagram_recent_posts_username_field_render() {
    $username = get_option('instagram_recent_posts_username');
    echo '<input type="text" name="instagram_recent_posts_username" value="' . esc_attr($username) . '" placeholder="e.g. okanaskincare" required />';
}

function instagram_recent_posts_frequency_field_render() {
    $frequency = get_option('instagram_recent_posts_frequency');
    echo '<input type="number" name="instagram_recent_posts_frequency" value="' . esc_attr($frequency) . '" min="15" placeholder="e.g. 15" required />';
}


// Define cache file path
function instagram_recent_posts_cache_file() {
    return plugin_dir_path(__FILE__) . 'instagram_recent_posts_cache.json';
}



/////////////////////////////////////////////////////
// CRON SCHEDULER
/////////////////////////////////////////////////////

// Add custom cron schedule intervals
add_filter('cron_schedules', 'instagram_recent_posts_cron_schedules');
function instagram_recent_posts_cron_schedules($schedules) {
    $frequency = get_option('instagram_recent_posts_frequency', 15); // Default frequency is 15 minutes
    $schedules['every_number_minutes'] = array(
        'interval' => intval($frequency) * 60, // Convert minutes to seconds
        'display'  => __('Every Number Minutes'),
    );
    return $schedules;
}

// Schedule or reschedule a cron job on plugin activation
register_activation_hook(__FILE__, 'instagram_recent_posts_schedule_cron');
function instagram_recent_posts_schedule_cron() {
    instagram_recent_posts_clear_cron(); // Clear any existing cron jobs
    if (!wp_next_scheduled('instagram_recent_posts_cron_hook')) {
        wp_schedule_event(time(), 'every_number_minutes', 'instagram_recent_posts_cron_hook');
    }
}

// Clear the cron job on plugin deactivation
register_deactivation_hook(__FILE__, 'instagram_recent_posts_clear_cron');
function instagram_recent_posts_clear_cron() {
    wp_clear_scheduled_hook('instagram_recent_posts_cron_hook');
}

// Hook the function to the custom cron event
add_action('instagram_recent_posts_cron_hook', 'instagram_recent_posts_cron_function');
function instagram_recent_posts_cron_function() {
    $username = get_option('instagram_recent_posts_username');
    instagram_recent_posts_fetch_data($username);
}

/////////////////////////////////////////////////////







// If saved settings and found any changes to username or frequency, then refetch posts
add_action('update_option', 'instagram_recent_posts_post_save_settings', 10, 3);
function instagram_recent_posts_post_save_settings($option, $old_value, $new_value) {
    if ($option === 'instagram_recent_posts_username') {

        file_put_contents(debug_file(), "USERNAME_UPDATED: {$new_value}" . PHP_EOL, FILE_APPEND);
        
        // Attempt to fetch posts when username changes
        instagram_recent_posts_fetch_data($new_value);
    }
    if ($option === 'instagram_recent_posts_frequency') {

        file_put_contents(debug_file(), "FREQUENCY_UPDATED: {$new_value}" . PHP_EOL, FILE_APPEND);
        
        // Update cron job schedule when frequency changes
        instagram_recent_posts_clear_cron(); // Clear existing cron job
        instagram_recent_posts_schedule_cron(); // Schedule new cron job with updated frequency
    }
}


// Fetch Instagram posts
function instagram_recent_posts_fetch_data($username) {
    file_put_contents(debug_file(), "FETCH_ATTEMPT for username: {$username}" . PHP_EOL, FILE_APPEND);
            
    //$username = get_option('instagram_recent_posts_username');
    $frequency = get_option('instagram_recent_posts_frequency');
    
    
    $cache_file = instagram_recent_posts_cache_file();
    $current_time = time();
    $formatted_date = date('H:i:s', $timestamp);
    
    // Debug
    file_put_contents(debug_file(), "username: {$username}" . PHP_EOL, FILE_APPEND);
    file_put_contents(debug_file(), "frequency: {$frequency}" . PHP_EOL, FILE_APPEND);
    file_put_contents(debug_file(), "formatted_date: {$formatted_date}" . PHP_EOL, FILE_APPEND);
        
    // Get Instagram posts data
    $posts = instagram_recent_posts_get_data($username);
    
    if ($posts !== false) {
        $cache_content = [
            'timestamp' => $current_time,
            'posts' => $posts
        ];
        
        file_put_contents($cache_file, json_encode($cache_content));
        
        file_put_contents(debug_file(), 'FETCHING_SUCCESSFUL' . PHP_EOL, FILE_APPEND);
    }

}

// Fetch data from Instagram API
function instagram_recent_posts_get_data($username) {
    $url = "https://i.instagram.com/api/v1/users/web_profile_info/?username={$username}";

    try {
        // Get request
        $response = wp_remote_get($url, [
            'headers' => [
                'x-ig-app-id' => '936619743392459',
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36',
                'Accept-Language' => 'en-US,en;q=0.9,ru;q=0.8',
                'Accept-Encoding' => 'gzip, deflate, br',
                'Accept' => '*/*',
            ]
        ]);

        // Retrieve the body of the response
        $body = wp_remote_retrieve_body($response);

        // Decode the JSON response
        $data = json_decode($body, true);

        // Check if the API response status is 'ok'
        if (isset($data['status']) && $data['status'] === 'ok') {
            $user = $data['data']['user'] ?? [];
            $posts = $user['edge_owner_to_timeline_media']['edges'] ?? [];

            return array_map(function ($post) {
                $node = $post['node'];
                return [
                    'media_type' => $node['__typename'],
                    'media_url' => $node['thumbnail_src'] ?? $node['display_url'],
                    'thumbnail_url' => $node['thumbnail_src'] ?? null,
                    'permalink' => 'https://www.instagram.com/p/' . $node['shortcode'],
                    'caption' => $node['edge_media_to_caption']['edges'][0]['node']['text'] ?? ''
                ];
            }, $posts);
        }
        else {
            throw new Exception('API response status is not OK');
        }
    }
    catch (Exception $e) {
        file_put_contents(debug_file(), 'FETCHING_ERROR: ' . $e->getMessage() . PHP_EOL, FILE_APPEND);
        return false;
    }
}


// Shortcode to display Instagram posts
add_shortcode('instagram_recent_posts', 'instagram_recent_posts_shortcode');
function instagram_recent_posts_shortcode() {
    
    // Get the cache file path
    $cache_file = instagram_recent_posts_cache_file();

    // Check if cache file exists
    if (!file_exists($cache_file)) {
        return '<p><strong>Status:</strong> Cached instagram posts not found. Please try another username.</p>';
    }

    // Get and decode cache data
    $cache_data = @file_get_contents($cache_file);
    if ($cache_data === false) {
        return '<p><strong>Status:</strong> Failed to read cached instagram posts.</p>';
    }

    $cached_data = json_decode($cache_data, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return '<p><strong>Status:</strong> Cached instagram posts contains invalid JSON data.</p>';
    }

    if (isset($cached_data['posts']) && is_array($cached_data['posts'])) {
        ob_start();
        ?>
        <style>
            .instagram-recent-posts {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                & .instagram-post {
                    & a {
                        & img {
                            max-width: 140px;
                            max-height: 140px;
                            display: block;
                            border: 1px solid gray;
                        }
                    }
                }
            }
        </style>
        <div class="instagram-recent-posts">
            <?php foreach ($cached_data['posts'] as $post): ?>
                <?php
                // Note:
                // Some instagram username accounts don't allow image thumbnails sharing from different domainname origins.
                //
                // Need to configure instagram, to allow access to photos/videos here:
                // https://www.youtube.com/watch?v=G9dnUlwoq_8
                //
                // e.g. username: okanaskincare (only allows images, but not videos)
                //
                if ($post['media_type'] === 'GraphVideo') continue
                ?>
                <div class="instagram-post">
                    <a href="<?php echo esc_url($post['permalink']); ?>" target="_blank">
                        <?php if ($post['media_type'] === 'GraphImage' || $post['media_type'] === 'GraphSidecar'): ?>
                            <img class="media-type-image" src="<?php echo esc_url($post['thumbnail_url']); ?>" alt="<?php echo esc_attr($post['caption']); ?>">
                        <?php elseif ($post['media_type'] === 'GraphVideo'): ?>
                            <img class="media-type-video" src="<?php echo esc_url($post['thumbnail_url']); ?>" alt="<?php echo esc_attr($post['caption']); ?>">
                        <?php endif; ?>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    return '<p>No posts available.</p>';
}





